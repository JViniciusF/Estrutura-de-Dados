for (i = 0; i < 10; i++);
    printf("Dez vezes Hello World");

if (x < y)
	if (pred(x)))
		printf("Um");
else if (x == y)
		printf("Dois");
else
		printf("Tres");
