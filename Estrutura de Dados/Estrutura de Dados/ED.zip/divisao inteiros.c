#include <stdio.h>

int main(void){
    printf ("%f\n", 1 / 2);
    system ("pause");
}
